package com.spring.hbm.mapping.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHibernateMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHibernateMappingApplication.class, args);
	}
}
