# spring-hibernate-join
This application gives idea about how to perform hibernate association join mapping 
