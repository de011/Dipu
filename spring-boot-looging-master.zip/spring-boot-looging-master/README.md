# spring-boot-looging
How to implement logging using sl4j and how to customize it using logback 
