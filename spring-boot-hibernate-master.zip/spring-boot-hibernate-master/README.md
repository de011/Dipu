# spring-boot-hibernate
How to intigrate spring boot with Hibernate
