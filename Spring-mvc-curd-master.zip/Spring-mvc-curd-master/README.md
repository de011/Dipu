# Spring-mvc-curd
how to develop standard Spring mvc curd application with Server side form Validation
