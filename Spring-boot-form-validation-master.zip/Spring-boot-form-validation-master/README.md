# Spring-boot-form-validation
How to validate form in server side using spring boot thymeleaf
