# Spring-Rest-Curd
Develop Curd operation using Spring Mvc Rest and Json
