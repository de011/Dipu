package com.spring.jms.reciver.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJmsReciverApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJmsReciverApplication.class, args);
	}
}
