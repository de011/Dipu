# spring-Boot-JMS-Sender
How to develop Spring boot JMS sender/Provider
