package com.spring.jms.sender.api.config;

public class PropertyConstants {

	public final static String BROKER_URL = "jms.url.broker";
	public final static String BROKER_USERNAME = "jms.username";
	public final static String BROKER_PASSWORD = "jms.password";
}