# spring-boot-simple-cache
How to enable simple  caching 
